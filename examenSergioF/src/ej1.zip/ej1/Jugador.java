package ej1;

public class Jugador extends Persona { //hijo de persona
	
	private int numero;
	private String posicion;
	private boolean activo;

	
	public Jugador(String nombre,  String apellidos,String dni, int numero, String posicion) {
		super(nombre, apellidos, dni);//se le añade super para que use el constructor del padre
		this.numero = numero;
		this.posicion = posicion;
	}


	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getPosicion() {
		return posicion;
	}

	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public void setinActivo(boolean activo) {
		this.activo = false;
	}
	public void entrenar() {
		activo=true;
		System.out.println("El jugador esta entrenando");
	}
	@Override
	void obtenerRol() { //método heredado de la clase padre "Persona"
		System.out.println("Jugador");
	}


	public void infoJ() {
		System.out.println("---------------------");
		System.out.println("Nombre: "+nombre+" "+apellidos);
		System.out.println("DNI: "+dni);
		System.out.println("Posicion: "+posicion);
		System.out.println("¿Entrenando?"+activo);
		System.out.println("---------------------");
	}
	
	
}
